particlesJS('particles-js',
  
  {
  "particles": {
    "number": {
      "value": 300,//鏁伴噺
      "density": {
        "enable": true, //鍚敤绮掑瓙鐨勭█瀵嗙▼搴�
        "value_area": 800 //鍖哄煙鏁ｅ竷瀵嗗害澶у皬
      }
    },
    "color": {
      "value": "#FFD700" //鍘熷瓙鐨勯鑹�
    },
    "shape": {
      "type": "circle", //鍘熷瓙鐨勫舰鐘� "circle" ,"edge" ,"triangle" ,"polygon" ,"star" ,"image" ,["circle", "triangle", "image"]
      "stroke": {
        "width": 0, //鍘熷瓙鐨勫搴�
        "color": "#FFC125" //鍘熷瓙棰滆壊
      },
      "polygon": {
        "nb_sides": 5 // 鍘熷瓙鐨勫杈瑰舰杈规暟
      },
      "image": {
        "src": "img/github.svg", // 鍘熷瓙鐨勫浘鐗囧彲浠ヤ娇鐢ㄨ嚜瀹氫箟鍥剧墖 "assets/img/yop.svg" , "http://mywebsite.com/assets/img/yop.png"
        "width": 100, //鍥剧墖瀹藉害
        "height": 100 //鍥剧墖楂樺害
      }
    },
    "opacity": {
      "value": 1, //涓嶉€忔槑搴�
      "random": true, //闅忔満涓嶉€忔槑搴�
      "anim": {
        "enable": true, //娓愬彉鍔ㄧ敾
        "speed": 1, // 娓愬彉鍔ㄧ敾閫熷害
        "opacity_min": 0, //娓愬彉鍔ㄧ敾涓嶉€忔槑搴�
        "sync": true 
      }
    },
    "size": {
      "value": 4, //鍘熷瓙澶у皬
      "random": true, // 鍘熷瓙澶у皬闅忔満
      "anim": {
        "enable": true, // 鍘熷瓙娓愬彉
        "speed": 4, //鍘熷瓙娓愬彉閫熷害
        "size_min": 0.3, 
        "sync": false
      }
    },
    "line_linked": {
      "enable": false, //杩炴帴绾�
      "distance": 150, //杩炴帴绾胯窛绂�
      "color": "#ffffff", //杩炴帴绾块鑹�
      "opacity": 0.4, //杩炴帴绾夸笉閫忔槑搴�
      "width": 1 //杩炴帴绾跨殑瀹藉害
    },
    "move": {
      "enable": true, //鍘熷瓙绉诲姩
      "speed": 1, //鍘熷瓙绉诲姩閫熷害
      "direction": "none", //鍘熷瓙绉诲姩鏂瑰悜   "none" ,"top" ,"top-right" ,"right" ,"bottom-right" ,"bottom" ,"bottom-left" ,"left" ,"top-left"
      "random": true, //绉诲姩闅忔満鏂瑰悜
      "straight": false, //鐩存帴绉诲姩
      "out_mode": "out", //鏄惁绉诲姩鍑虹敾甯�
      "bounce": false, //鏄惁璺冲姩绉诲姩
      "attract": { 
        "enable": false, // 鍘熷瓙涔嬮棿鍚稿紩
        "rotateX": 600, //鍘熷瓙涔嬮棿鍚稿紩X姘村钩璺濈
        "rotateY": 600  //鍘熷瓙涔嬮棿鍚稿紩Y姘村钩璺濈
      }
    }
  },
  "interactivity": {
    "detect_on": "canvas", //鍘熷瓙涔嬮棿浜掑姩妫€娴� "canvas", "window"
    "events": {
      "onhover": {
        "enable": false, //鎮仠
        "mode": "grab" //鎮仠妯″紡      "grab"鎶撳彇涓磋繎鐨�,"bubble"娉℃搏鐞冩晥鏋�,"repulse"鍑婚€€鏁堟灉,["grab", "bubble"]
      },
      "onclick": {
        "enable": false,  //鐐瑰嚮鏁堟灉
        "mode": "repulse"  //鐐瑰嚮鏁堟灉妯″紡   "push" ,"remove" ,"bubble" ,"repulse" ,["push", "repulse"]
      },
      "resize": true // 浜掑姩浜嬩欢璋冩暣
    },
    "modes": {
      "grab": {
        "distance": 100, //鍘熷瓙浜掑姩鎶撳彇璺濈
        "line_linked": { 
          "opacity": 0.8  //鍘熷瓙浜掑姩鎶撳彇璺濈杩炵嚎涓嶉€忔槑搴�
        }
      },
      "bubble": {
        "distance": 250, //鍘熷瓙鎶撳彇娉℃搏鏁堟灉涔嬮棿鐨勮窛绂�
        "size": 4, // 鍘熷瓙鎶撳彇娉℃搏鏁堟灉涔嬮棿鐨勫ぇ灏�
        "duration": 2, //鍘熷瓙鎶撳彇娉℃搏鏁堟灉涔嬮棿鐨勬寔缁簨浠�
        "opacity": 1, //鍘熷瓙鎶撳彇娉℃搏鏁堟灉閫忔槑搴�
        "speed": 3 
      },
      "repulse": {
        "distance": 400, //鍑婚€€鏁堟灉璺濈
        "duration": 0.4 //鍑婚€€鏁堟灉鎸佺画浜嬩欢
      },
      "push": {
        "particles_nb": 4 //绮掑瓙鎺ㄥ嚭鐨勬暟閲�
      },
      "remove": {
        "particles_nb": 2
      }
    }
  },
  "retina_detect": true
}

);